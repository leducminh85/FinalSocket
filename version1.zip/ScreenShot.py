import pyscreenshot


def Take_Screenshot(filename):
    image = pyscreenshot.grab()
  
    
    image.save(filename)




    


    